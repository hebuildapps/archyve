"use strict";
(() => {
  // src/welcome.ts
  var SUPABASE_URL = "https://dvxrbtopucnxjmfghhme.supabase.co";
  var SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImR2eHJidG9wdWNueGptZmdoaG1lIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODY0NzA4NTYsImV4cCI6MjEwMjA0Njg1Nn0.8V4PUlu3mm5g-MtClYIBoFetUe5hkD9x-UFwORwRvJo";
  document.addEventListener("DOMContentLoaded", () => {
    const configureBtn = document.getElementById("configure-btn");
    if (configureBtn) {
      configureBtn.addEventListener("click", (e) => {
        e.preventDefault();
        if (chrome.runtime.openOptionsPage) {
          chrome.runtime.openOptionsPage(() => {
            if (chrome.runtime.lastError) {
              chrome.tabs.create({ url: chrome.runtime.getURL("options.html") });
            }
          });
        } else {
          chrome.tabs.create({ url: chrome.runtime.getURL("options.html") });
        }
      });
    }
    const tabSignIn = document.getElementById("tab-signin");
    const tabSignUp = document.getElementById("tab-signup");
    const authForm = document.getElementById("auth-form");
    const authEmailInput = document.getElementById("auth-email");
    const authPasswordInput = document.getElementById("auth-password");
    const authSubmitBtn = document.getElementById("auth-submit-btn");
    const authSubmitText = document.getElementById("auth-submit-text");
    const authStatus = document.getElementById("auth-status");
    const authIndicator = document.getElementById("auth-indicator");
    const loggedInView = document.getElementById("logged-in-view");
    const loggedOutView = document.getElementById("logged-out-view");
    const userEmailDisplay = document.getElementById("user-email-display");
    const userAvatar = document.getElementById("user-avatar");
    const btnSignOut = document.getElementById("btn-signout");
    let isSignUpMode = false;
    const registerView = document.getElementById("register-view");
    if (tabSignIn && tabSignUp) {
      tabSignIn.addEventListener("click", () => {
        tabSignIn.classList.add("active");
        tabSignUp.classList.remove("active");
        if (authForm) authForm.style.display = "flex";
        if (registerView) registerView.style.display = "none";
        hideStatus();
      });
      tabSignUp.addEventListener("click", () => {
        tabSignUp.classList.add("active");
        tabSignIn.classList.remove("active");
        if (authForm) authForm.style.display = "none";
        if (registerView) registerView.style.display = "block";
        hideStatus();
      });
    }
    function showStatus(message, isError) {
      if (!authStatus) return;
      authStatus.textContent = message;
      authStatus.className = `auth-status-box ${isError ? "error" : "success"}`;
    }
    function hideStatus() {
      if (!authStatus) return;
      authStatus.className = "auth-status-box";
      authStatus.textContent = "";
    }
    function updateLoggedInState(email) {
      if (authIndicator) {
        authIndicator.textContent = "connected";
        authIndicator.style.color = "#9ee618";
      }
      if (userEmailDisplay) userEmailDisplay.textContent = email;
      if (userAvatar) userAvatar.textContent = email.charAt(0).toLowerCase();
      if (loggedOutView) loggedOutView.style.display = "none";
      if (loggedInView) loggedInView.style.display = "flex";
    }
    function updateLoggedOutState() {
      if (authIndicator) {
        authIndicator.textContent = "";
      }
      if (loggedInView) loggedInView.style.display = "none";
      if (loggedOutView) loggedOutView.style.display = "block";
    }
    async function checkActiveSession() {
      chrome.storage.local.get(["userSession"], (result) => {
        if (result.userSession?.user?.email) {
          updateLoggedInState(result.userSession.user.email);
        } else {
          updateLoggedOutState();
        }
      });
    }
    checkActiveSession();
    if (btnSignOut) {
      btnSignOut.addEventListener("click", async () => {
        chrome.storage.local.remove(["userSession"], () => {
          updateLoggedOutState();
          showStatus("Signed out successfully.", false);
        });
      });
    }
    if (authForm) {
      authForm.addEventListener("submit", async (e) => {
        e.preventDefault();
        const email = authEmailInput.value.trim();
        const password = authPasswordInput.value.trim();
        if (!email || !password) return;
        authSubmitBtn.disabled = true;
        authSubmitText.textContent = "Signing in...";
        hideStatus();
        try {
          const endpoint = `${SUPABASE_URL}/auth/v1/token?grant_type=password`;
          const res = await fetch(endpoint, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "apikey": SUPABASE_ANON_KEY
            },
            body: JSON.stringify({ email, password })
          });
          const data = await res.json();
          if (!res.ok) {
            throw new Error(data.error_description || data.msg || data.message || "Authentication failed");
          }
          chrome.storage.local.set({ userSession: data }, () => {
            updateLoggedInState(data.user?.email || email);
            showStatus("Signed in successfully!", false);
          });
        } catch (err) {
          showStatus(err.message || "Error occurred during authentication.", true);
        } finally {
          authSubmitBtn.disabled = false;
          authSubmitText.textContent = "Sign In";
        }
      });
    }
  });
})();
//# sourceMappingURL=welcome.js.map