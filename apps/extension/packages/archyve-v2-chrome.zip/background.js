"use strict";
(() => {
  // src/background/serviceWorker.ts
  var SUPPORTED_DOMAINS = [
    "ieeexplore.ieee.org",
    "link.springer.com",
    "sciencedirect.com",
    "jstor.org",
    "arxiv.org",
    "pubmed.ncbi.nlm.nih.gov",
    "pmc.ncbi.nlm.nih.gov",
    "ncbi.nlm.nih.gov",
    "nature.com",
    "doi.org"
  ];
  function isSupportedUrl(url) {
    if (!url) return false;
    try {
      const parsed = new URL(url);
      return SUPPORTED_DOMAINS.some((domain) => parsed.hostname.includes(domain));
    } catch {
      return false;
    }
  }
  function triggerArchyve(url) {
    chrome.storage.local.get(["webUrl"], (result) => {
      const baseWebUrl = result.webUrl || "https://archyve.xyz";
      if (url && isSupportedUrl(url)) {
        const targetUrl = `${baseWebUrl}/${encodeURIComponent(url)}`;
        chrome.tabs.create({ url: targetUrl });
      } else {
        chrome.tabs.create({ url: baseWebUrl });
      }
    });
  }
  chrome.runtime.onInstalled.addListener((details) => {
    const currentVersion = chrome.runtime.getManifest().version;
    if (details.reason === "install") {
      chrome.storage.local.set({ lastSeenVersion: currentVersion }, () => {
        chrome.tabs.create({ url: chrome.runtime.getURL("welcome.html") });
      });
    } else if (details.reason === "update") {
      chrome.storage.local.get(["lastSeenVersion"], (result) => {
        if (result.lastSeenVersion !== currentVersion) {
          chrome.storage.local.set({ lastSeenVersion: currentVersion }, () => {
            chrome.runtime.openOptionsPage();
          });
        }
      });
    }
    chrome.contextMenus.create({
      id: "open-archyve",
      title: "open with archyve",
      contexts: ["page"],
      documentUrlPatterns: [
        "*://ieeexplore.ieee.org/document/*",
        "*://link.springer.com/article/*",
        "*://link.springer.com/chapter/*",
        "*://link.springer.com/referenceworkentry/*",
        "*://*.sciencedirect.com/science/article/pii/*",
        "*://*.jstor.org/stable/*",
        "*://arxiv.org/abs/*",
        "*://pubmed.ncbi.nlm.nih.gov/*",
        "*://pmc.ncbi.nlm.nih.gov/*"
      ]
    });
  });
  chrome.contextMenus.onClicked.addListener((info, tab) => {
    if (info.menuItemId === "open-archyve" && tab?.url) {
      triggerArchyve(tab.url);
    }
  });
  chrome.action.onClicked.addListener((tab) => {
    if (tab?.url) {
      triggerArchyve(tab.url);
    }
  });
  chrome.commands.onCommand.addListener(async (command) => {
    console.log("[Archyve] Command received:", command);
    if (command === "trigger_archyve") {
      try {
        const tabs = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
        const activeTab = tabs[0] || (await chrome.tabs.query({ active: true, currentWindow: true }))[0];
        triggerArchyve(activeTab?.url);
      } catch (err) {
        console.error("[Archyve] Shortcut query error:", err);
        triggerArchyve();
      }
    }
  });
  chrome.runtime.onMessage.addListener((message) => {
    if (message.action === "trigger_analysis" && message.url) {
      triggerArchyve(message.url);
    }
  });
})();
//# sourceMappingURL=background.js.map