"use strict";
(() => {
  // src/options.ts
  document.addEventListener("DOMContentLoaded", () => {
    const groqApiKeyInput = document.getElementById("groq-api-key");
    const apiKeyInput = document.getElementById("api-key");
    const saveBtn = document.getElementById("save-btn");
    const statusDiv = document.getElementById("status");
    chrome.storage.local.get(["groqApiKey", "apiKey"], (result) => {
      if (result.groqApiKey) {
        groqApiKeyInput.value = result.groqApiKey;
      }
      if (result.apiKey) {
        apiKeyInput.value = result.apiKey;
      }
    });
    saveBtn.addEventListener("click", () => {
      const groqApiKey = groqApiKeyInput.value.trim();
      const apiKey = apiKeyInput.value.trim();
      chrome.storage.local.set({ groqApiKey, apiKey }, () => {
        statusDiv.style.display = "block";
        setTimeout(() => {
          statusDiv.style.display = "none";
        }, 3e3);
      });
    });
  });
})();
//# sourceMappingURL=options.js.map