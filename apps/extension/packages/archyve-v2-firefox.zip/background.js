"use strict";
(() => {
  // src/background/serviceWorker.ts
  var SUPPORTED_DOMAINS = [
    "ieeexplore.ieee.org",
    "link.springer.com",
    "sciencedirect.com",
    "jstor.org",
    "arxiv.org"
  ];
  function isSupportedUrl(url) {
    try {
      const parsed = new URL(url);
      return SUPPORTED_DOMAINS.some((domain) => parsed.hostname.includes(domain));
    } catch {
      return false;
    }
  }
  function triggerArchyve(url) {
    if (!isSupportedUrl(url)) {
      console.warn("Archyve: Unsupported URL:", url);
      return;
    }
    chrome.storage.local.get(["webUrl"], (result) => {
      const baseWebUrl = result.webUrl || "https://archyve.xyz";
      const targetUrl = `${baseWebUrl}/${encodeURIComponent(url)}`;
      chrome.tabs.create({ url: targetUrl });
    });
  }
  chrome.runtime.onInstalled.addListener((details) => {
    const currentVersion = chrome.runtime.getManifest().version;
    if (details.reason === "install") {
      chrome.storage.local.set({ lastSeenVersion: currentVersion }, () => {
        chrome.tabs.create({ url: chrome.runtime.getURL("welcome.html") });
      });
    } else if (details.reason === "update") {
      chrome.storage.local.get(["lastSeenVersion"], (result) => {
        if (result.lastSeenVersion !== currentVersion) {
          chrome.storage.local.set({ lastSeenVersion: currentVersion }, () => {
            chrome.runtime.openOptionsPage();
          });
        }
      });
    }
    chrome.contextMenus.create({
      id: "open-archyve",
      title: "open with archyve",
      contexts: ["page"],
      documentUrlPatterns: [
        "*://ieeexplore.ieee.org/document/*",
        "*://link.springer.com/article/*",
        "*://link.springer.com/chapter/*",
        "*://link.springer.com/referenceworkentry/*",
        "*://*.sciencedirect.com/science/article/pii/*",
        "*://*.jstor.org/stable/*",
        "*://arxiv.org/abs/*"
      ]
    });
  });
  chrome.contextMenus.onClicked.addListener((info, tab) => {
    if (info.menuItemId === "open-archyve" && tab?.url) {
      triggerArchyve(tab.url);
    }
  });
  chrome.action.onClicked.addListener((tab) => {
    if (tab?.url) {
      triggerArchyve(tab.url);
    }
  });
  chrome.commands.onCommand.addListener((command) => {
    if (command === "trigger_archyve") {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        const activeTab = tabs[0];
        if (activeTab?.url) {
          triggerArchyve(activeTab.url);
        }
      });
    }
  });
  chrome.runtime.onMessage.addListener((message) => {
    if (message.action === "trigger_analysis" && message.url) {
      triggerArchyve(message.url);
    }
  });
})();
//# sourceMappingURL=background.js.map